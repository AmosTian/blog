> adj. 怀疑的

**同义词**
- be suspicious / skeptical of 怀疑

**skeptics**
> n. 怀疑者