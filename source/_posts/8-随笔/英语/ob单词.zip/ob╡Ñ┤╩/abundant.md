> adj. 充足的

**搭配**

- be abundant in sth：sth 充足 
	- be abundant in resources

We have abundant evidence to prove his guilt.

**同义词**
- sufficient 充足的

**反义词**
- deficient 不足的；有缺点的(人)
	- deficiency n. 缺陷，缺少(not have enough)
- [devoid](devoid.md) 

**abundance**
> n. 大量，丰盛，充裕

**区别**
- 足够的(程度小) [adequate](adequate.md)




