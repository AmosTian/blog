> v. 加强

**搭配**

- strengthen their sense of identity 加强认同感

> n. 强项，优点

