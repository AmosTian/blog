**搭配**
- huge / intense / sharp / acute 剧痛
	- acute 尖锐的
	- acute angle 锐角
- stabbing 小刀刮
- shock 刺痛
- moderate 适量的

**同义词**
- ache
	- my back aches

**近义词**
- itch 痒

bite
> v. 咬;叮;蜇;

bite-bit-bitten

**同义词**
- sting-stung-stung
	- be stung by mosquito 被蚊子叮

**swell**
> v. 膨胀，肿胀;

swell-swelled-swollen