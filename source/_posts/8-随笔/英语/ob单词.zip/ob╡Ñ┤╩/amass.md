> v. （大量）聚集，积累

**近义词**
- accumulate
- collect
