> n/v 替代

**搭配**
- subtitute A for B 同A代替B

> adj.  替补的;

**同义词**
- alternative