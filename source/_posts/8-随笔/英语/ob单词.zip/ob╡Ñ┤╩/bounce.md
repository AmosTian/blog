> v. 反弹

- With Covid-19 hitting the world, the medical stock index is bouncing back.

**搭配**
- bounce bed 蹦床
- bounce back反弹