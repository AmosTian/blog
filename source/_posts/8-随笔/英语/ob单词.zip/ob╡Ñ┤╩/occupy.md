> v. 占据

**搭配**

- be occupied with 被...占据；忙于

**同义词**
- be overwhelmed ([overwhelm](overwhelm.md)) with
- [prevail](prevail.md) 

**occupation**
> n. 占据，控制

> n. 工作

- job
- employment
- profession（需要较高教育门槛）
- vocation（认为特别适合自己的工作或生活方式）
- job（一项任务，一件工作）
- work