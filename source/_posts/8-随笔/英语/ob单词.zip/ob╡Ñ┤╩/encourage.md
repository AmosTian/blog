> v. 鼓励


discourage
> v. 不鼓励

