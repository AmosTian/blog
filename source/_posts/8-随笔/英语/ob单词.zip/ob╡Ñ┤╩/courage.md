> n. 勇气

[[encourage]]
> v. 鼓励

**discourage**
> v. 使泄气；劝阻

- discourage sb from doing 
- [[prevent]]
- warn sb against
