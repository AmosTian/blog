> adj. 巨大的

**同义词**
- enormous
- gigantic