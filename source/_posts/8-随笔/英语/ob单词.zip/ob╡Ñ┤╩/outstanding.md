> adj. 杰出的

**搭配**

-  [[scholarship]] for outstanding academic / excellence performance

**同义词**

- excellent
- successful
- eminent
- professional

