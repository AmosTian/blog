> v. 进化

**evolution** n. 

**evolutionary** adj.
