> 预料

**相关词汇**

- [[linguistics]] 语言学

职业
- guidance 指导
- counseior 咨询师
- deputy academic head 副学术负责人
	- deputy admistrative head 副行政首长
- deem 系主任，校长
- columnist 专栏作家

