> adj. 耐用的

**同义词**
耐用的
- durable
- robust
持久的
- persistent
- permanent
- sustained
- [[perennial]]
- enduring——[[endure]] v. 
- lasting

**反义词**
- [[faddish]]

**wear**
> v.  (及物动词)穿着; 磨损

> v. (不及物动词)耐用，保持不变；磨损

> adj. 令人精疲力尽的

**同义词**

- exhausted
- tired

