> v. 惊喜，惊吓(中性)

**同义词**
**surprising** adj. 令人吃惊的
- astonishing

**区别**
- shocked adj. 震惊的(坏消息)
- annoy sb惹怒，使...不高兴
	- irritate