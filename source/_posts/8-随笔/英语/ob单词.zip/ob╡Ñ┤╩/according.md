> v. 给予；(与...一致)，符合


> adj. 相符的

**搭配**

- according to 依据


**accordingly**
> adv. 相应地