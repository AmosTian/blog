> n. 同伴；

**近义词**

- partner