> vi. 持久，持续

- These words will endure as long as people live who love freedom.

> vt. 经历，遭受；忍耐，忍受

- The company has just endured such a significant economic loss.

**同义词**
- [undergo](undergo.md)
- tolerate
- put up with
- bear
- stand

**搭配**
- endure [hazard](hazard.md) / suffering / tough/[harsh](harsh.md) time 忍受危险/痛苦/艰难时光
- endure long period of pandemic / divorce 经受长期的疫情、经历离婚
- endure such a long wait 经历了长时间的等待

**enduring**
> adj. 持久的

**同义词**
- persistent
- permanent
- sustained
- maintaing love 持久的
	- car maintenance 汽车保养
- [perennial](perennial.md)
- lasting

**endurable**
> adj. 可忍受的，长期的

**搭配**
- endurable/ever-lasting/long term pain 可忍受的/长期的/持续的痛苦
- engagement / wedding / enduring/suffering ring 订婚戒指/ 结婚戒指/ 婚后

[pain](pain.md)

**反义词**
- [faddish](faddish.md)