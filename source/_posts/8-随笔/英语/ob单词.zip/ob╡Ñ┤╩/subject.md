> n. 话题；学科；对象，题材

> v. 使臣服，受到...影响

- be subject to 
	Fluctuations in prices may be subject to marcket factors.