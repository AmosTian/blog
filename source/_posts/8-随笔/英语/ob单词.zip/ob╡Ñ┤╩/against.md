> prep. 反对

- **in a race against time** 与时间赛跑

> prep. 倚靠

**搭配**
- be against the wall 靠着墙

