> v. 惹恼，打扰

**例句**

- His constant joking was beginning to annoy her.

**同义词**

- irritate v. 刺激（皮肤，身体部位）；使烦恼（不断重复的事情）
