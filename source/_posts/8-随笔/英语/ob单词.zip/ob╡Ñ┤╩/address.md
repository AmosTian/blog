> n. 地址


> vt. 解决（问题）

- address the urgent problem/issues 解决急切的问题

**同义词**

- deal with issues 
	- **back door dealing 幕后操作**
- solve
- tackle school bullying/violence 校园霸凌
- tackle a range of issues

> v. +sb 打招呼



