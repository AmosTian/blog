> v. 占据

**搭配**
- be obsessed/obsessive with 过度在意
	- Chinese parents are obsessed/obsessive with their children's grades.
- Obessive-Compulsive Disorder 强迫症OCD

**obsession**
> n. （令人着迷的）事物；困扰

- sth is / are one's obsession