> n. （专家或长者的）劝告，建议，法律顾问

**例句**

- The court then heard counsel for the dead woman's father

> v. 提供专业资讯，建议（做某事）


**例句**

- My advisers counselled me to do nothing

**counselor**

> n. 顾问，律师

**搭配**

- guidance counselor 规划咨询师


