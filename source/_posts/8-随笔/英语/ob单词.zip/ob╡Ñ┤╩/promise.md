> n. 承诺；前途，指望；

**同义词**
- prospect