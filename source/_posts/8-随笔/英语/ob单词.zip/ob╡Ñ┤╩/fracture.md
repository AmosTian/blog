> n. 骨折；（状态）断裂，破裂


> v. (使)断裂，破裂

**fraction**

> n. 小部分，少量，

**搭配**

- a fraction of a second 瞬间，白驹过隙