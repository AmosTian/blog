> adj. 严厉的；艰苦的

- under harsh condition 在艰苦环境下

**同义词**
- tough life