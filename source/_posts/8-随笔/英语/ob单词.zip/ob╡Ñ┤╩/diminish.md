> v. 减少

**同义词**
- decline
	- declining adj. 下滑的；衰退的
	- declinced 过去式
	- **health declined rapidly 健康状况迅速下降**
- decrease
- lessen
- recede
- shrink-shrunk-shrank
- subside
- wane
- descend
- drop
- go down

**骤降**
- plunge 跳水

**反义词——增长**
- go up  
- increase
- ascend
- rise
	- on the rise around the globe 全球范围内上涨
**飙升**
- soar
- be rocketing to a new high