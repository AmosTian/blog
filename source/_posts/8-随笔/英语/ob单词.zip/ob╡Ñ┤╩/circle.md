> n. 圈，循环

> n. (一类人)圈子

- [[academic]] circle 学术圈
