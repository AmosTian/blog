> v. 引起;引发;激起;激怒;挑衅;刺激

**搭配**
- provoke a war / conflict / debate 挑起战争/冲突/争论

The article was intended to provoke discussion.

[trigger](trigger.md)

**provocatiive**
> adj. 挑衅的/挑逗的