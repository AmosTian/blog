> adj. 传统的

**同义词**
- traditional

**搭配**
- conventional wisdom tells us 老话说得好