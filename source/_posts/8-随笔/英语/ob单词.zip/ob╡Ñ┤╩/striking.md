> adj. 闲逛

hang out 闲闹