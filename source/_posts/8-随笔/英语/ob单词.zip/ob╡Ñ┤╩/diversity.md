> n. 多样性

**同义词**
- variety 

**diverse**
> adj. 多种多样的

- variable 可变的