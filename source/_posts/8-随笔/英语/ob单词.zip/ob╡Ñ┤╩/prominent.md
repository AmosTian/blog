> adj.  突出

**搭配**
- come into prominence
- become prominent

He played a prominent part in the campaign.