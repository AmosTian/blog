> n. 人类学家

- biochemistry 生物化学
- chemist 化学家，药剂师
- psychologist 心理学家
- psychiatrist 精神学家