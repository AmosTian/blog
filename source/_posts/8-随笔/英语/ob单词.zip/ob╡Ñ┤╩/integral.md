> adj. 必要的；不可或缺的
> being an essential part of something

**搭配**
- an integral part of sth
	- Music is an integral part of the school's curriculum.

**同义词**
- **必要的**
	- necessary
	- indispensable
	- inevitable
	- inexorable 不可阻挡的，不可避免的
	- [essential](essential.md) ——essential 

**integrity**
> n. 完整性(物)；完备性(人)
> 良好品质，诚实，正直，完整

- integrity of territory

**同义词**
- sound personality system 健全的人格

**integration**
一体