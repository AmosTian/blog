> adj. 足够的

**同义词**
- enough

**辨析**
- 充足的(程度大) [abundant](abundant.md)