> v. 污染，弄脏;

- contaminate/pollute wate/air 污染水/空气