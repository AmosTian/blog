> n. 年龄，时代

**搭配**

- in the age of 在... 时代
- age-old 古老的 story / problem / tradition 长期的/难以解决
	- [conventional](conventional.md)