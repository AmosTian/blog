> adj. 随后的，之后的

Subsequent research has produced even better results.