> adj. 全面的，彻底的

**同义词**
- complete
	- make through / throughly investigation 做全面调查

**thoroughly**
> adv. 彻底地，完全地

- radically
- dramitically

**区别**
- through prep. 通过，穿过
- [throughout](throughout.md) 始终 
- tough adj. 艰难的 
	- tough guy / time 