> n. 设备（家居设备）

**同义词**

- equipment 较大仪器或机器
- facility 学校，厂房
- implementor 
- gadget （零星）设备
