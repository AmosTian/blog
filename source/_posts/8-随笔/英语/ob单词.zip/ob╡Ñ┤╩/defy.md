> v. 拒绝，违抗
> behavior showing you are not willing to obey

**反义词**
- obey v. 遵守

**defiance**
> n. 违抗

**搭配**
- in defiance of bias/prejudice/sb's wishes