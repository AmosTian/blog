> adj. 应季的

后置形容词，修饰前一个名词

fruits and vegetables in season 