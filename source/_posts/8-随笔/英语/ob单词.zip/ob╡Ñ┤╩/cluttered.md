> adj. 杂乱的

**同义词**
- messy adj.
	- in a mess
