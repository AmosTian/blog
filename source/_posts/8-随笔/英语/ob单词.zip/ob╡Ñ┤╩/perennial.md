> adj. 终年的


- all the year
	- Arctic and Antartic are covered with snow and ice perennially.
		- arctic
			北极区的
		- antarctic
			南极区的
