> adj. 崎岖的;坚固耐用;崎岖不平的;粗犷;强固

Five million visitors come here every year to see these rugged lands.