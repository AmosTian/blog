> v. 反驳; 相反

- The two stories contradict each other.

**同义词**
- On the contrary 相反地

**contradiction**
> n. 对立面