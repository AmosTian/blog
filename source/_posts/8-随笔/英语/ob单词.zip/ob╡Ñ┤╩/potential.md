> adj. 潜在的；

**搭配**

- potential customers
- a potential prime minister：未来的首相

> n. 可能性，潜力

