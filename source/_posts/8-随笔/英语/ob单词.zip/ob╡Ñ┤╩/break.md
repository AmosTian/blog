

**搭配**

- break away 逃脱；消散
- break away from 脱离，与...脱离关系
- break in 闯入；突然开始
- break out 爆发；准备使用
- break down 破坏；出故障；
- break up 破碎；解散；分手
- break up into 分成几部分
- break through 突破
- break off 突然住口；断绝；暂停


break作为词根

- break-through n. 巨大的突破
- ground-breaking adj. 突破性的
	- cutting edge / leading  前沿，划时代的 technology / theory
- tremendous stride