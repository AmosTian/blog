
despite sth / in despite of
- despite this intimacy 尽管如此亲密

**同义词**
- notwithstanding 
	Notwithstanding some major financial problems, the school has had a successful year.