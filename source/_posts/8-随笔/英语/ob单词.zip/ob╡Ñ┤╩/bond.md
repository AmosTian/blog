>n. 结合

**搭配**
- bond to 结合
	They can be programmed to bond to certain type of cell. 
- blood/family bond 血亲