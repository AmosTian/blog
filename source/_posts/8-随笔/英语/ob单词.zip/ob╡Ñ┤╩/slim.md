
**slimmed-down** version 精简版本