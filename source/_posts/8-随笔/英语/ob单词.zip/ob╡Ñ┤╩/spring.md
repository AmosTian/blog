> v. 源于

spring-spiang-sprung

**搭配**
- spring / originate  from 

**origin**
> n. 起源;源头;起因;身世

- the origin of 