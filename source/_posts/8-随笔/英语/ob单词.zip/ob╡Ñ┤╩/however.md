> adv. 然而；不管怎样

however, some people think differently

> conj. 虽然