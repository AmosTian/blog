> adv. 程度高 ，高度...、

**搭配**

- highly recommended
