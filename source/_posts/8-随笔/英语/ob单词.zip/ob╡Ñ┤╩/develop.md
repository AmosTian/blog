> v. 发展；研制；（使）成长；（疾病）侵袭

**搭配**
- develop a smartphone App

**developing**

>adj. 发展中的

**developed**

> adj. 发达的

**development**

> n. 研制成果