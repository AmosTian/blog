> v. 免疫

**搭配**

- be immune to ：对...免疫

**immunity**
> n. 免疫力

