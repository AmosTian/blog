
**搭配**

- bring up 教育 ; 提出 ; 
- bring about 带来，导致
- bring out 公布，出版
- bring in 引进，带来