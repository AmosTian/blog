> 一些人

- However, some people think differently. 用于正反观点论证
- contrary to what some believe 与寻常人想法相反