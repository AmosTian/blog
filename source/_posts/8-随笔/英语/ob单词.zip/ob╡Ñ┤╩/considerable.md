> adj. 大量的

**同义词**
- [abundant](abundant.md)
- masive
- plentiful
- vast
- sizeable 可观的
- substaintial 大量的，巨额的
- countless 不计其数的
- neumerious
- immeasurable
- large-scale 大规模的（[工业](工业.md)）

**consider**
> v. 考虑到，鉴于

**搭配**
- Consider that（句首）：
- Given that
	Given that we are related, I can't coment on it.
- Take sth into consideration

**considerate**
> adj. 考虑周到的