>adj. 缺乏，完全没有

**搭配**

- be devoid of (表示某人或某物完全没有某种特质、品质或元素)
	- He seems to **be devoid of** compassion.
- be lack of
- sth derived——缺乏sth