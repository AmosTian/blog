> v. 损害，削弱

**搭配**

- be visually impaired destoryed 

**-pair**

- despair v. 使...失望
- repair v. 修理，修补