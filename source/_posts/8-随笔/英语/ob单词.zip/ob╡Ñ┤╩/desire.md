> n. 愿望; 欲望; 渴望
> a very strog want or wish

- He is filled with a desire to seek social justice.

> v. 

- Fewer people desire to live in the north of the country.