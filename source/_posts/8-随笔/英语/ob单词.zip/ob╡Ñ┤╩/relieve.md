> v. 减轻，减缓

**例句**

- Drugs can relieve much of the pain, yet they may cause considerable damage to our body.
	damage v. n. 破坏，损坏
	- wreak havoc in sth
	- do harm in sth

**辨析**

[[release]] ： v. 发行；释放