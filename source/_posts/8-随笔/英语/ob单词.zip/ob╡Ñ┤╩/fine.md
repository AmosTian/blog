> adj. 好的；高质量的

> adv. 可接受，够好

> n. 罚款，罚金

> v. 处以...罚金

> 词根

- [[refine]] 提炼
- confine v. 限制