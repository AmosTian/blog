hypertension 高血压
- high blood pressure
hyper-connected 高度关联
