> v. 离开，强调从原来地方离开

**go away from**

**搭配**
- leave 地名：离开某地
- leave for 地名 ：到某地去
- leave A for B：从A到B地

> v. 舍弃(由离开引申为舍弃) ，忍痛割爱，感情色彩重

> v. 留下（及物动词）

- leave book on the bus

leave sb sth = leave sth to sb = leave sth for sb