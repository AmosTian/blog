> adj. 牵连其中的

His assistant is implicated in a financial case.