> automated teller machine

**CDC**
Centers for Disease Control and prevention

**OCD**
Obsessive-Compulsive Disorder 强迫症([obsess](obsess.md))