**necessity**
> n. 必要条件

- a necessity for sth sth 的需要/必要条件