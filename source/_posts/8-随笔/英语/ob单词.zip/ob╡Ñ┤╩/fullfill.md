> v. 完成，实现

**同义词**

- [[accomplish]]
- complete
- [[finish]]
- achieve
- realise
- wort out
- carry out

**词组**

fullfill their sake 实现追求
