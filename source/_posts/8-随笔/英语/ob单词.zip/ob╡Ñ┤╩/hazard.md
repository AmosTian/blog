> n. 危险

**同义词**
- danger
- disaster
	- disastrous 灾难性的

**搭配**
- severe adj. 严重的
- fatal/deadly 致命的
- virulent/poisonous  剧毒的

[工业](工业.md)
[contaminate](contaminate.md)

bacteria(复数)
> n. 细菌
- bacterium 细菌（单数）

**搭配**
- foodborne adj. 食物传播的
- zoonotic diseases 动物源性的疾病
	- zoonosis 动物传人
	- veterinarian 兽医
- infectious 有传染性的
- [outbreak](outbreak.md) 爆发
- epidemic 传染病 pandemic 大规模流感
	- epidemiologist 流行病学家
- Global incidence 全球发病率

**sanitary**
> adj 卫生的

- sanitary condition 卫生环境


