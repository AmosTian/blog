
**stressed** adj. 有压力的
- I feel so stressed / stressful

