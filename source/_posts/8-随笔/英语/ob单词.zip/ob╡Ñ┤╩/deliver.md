> v. 传送

**搭配**
- deliver care/love/service/drugs/treatment/positive energy/value

So I am using the media as a tool to deliver the message of  philosophy.

**delivery**
> n. 递送，投递;

