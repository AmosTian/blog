> adj. 实际的

- Passion turns out to be practical.

**同义副词**
- in fact
- almost
- virtually

**practice**
> v. 练习