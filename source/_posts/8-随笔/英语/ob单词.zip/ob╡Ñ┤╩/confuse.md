> v. 混淆，使迷惑

**搭配**

- financial confuse：财产纠纷

**同义词**

- perplex
- puzzle