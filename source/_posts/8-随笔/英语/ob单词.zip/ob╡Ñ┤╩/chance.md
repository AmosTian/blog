> n. 机会

**搭配**
- [leave](leave.md) to chance 听天由命

**同义词**
- opportunity
	- golden opportunity


