> n. 峰值

**搭配**
- at the peak / summit 