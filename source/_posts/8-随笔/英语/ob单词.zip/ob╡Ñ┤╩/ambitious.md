> n. 抱负

**同义词**
- aspiring