> adj. 脆弱的

be vulnerable to 易受...伤害

- vulnerable group 弱势群体