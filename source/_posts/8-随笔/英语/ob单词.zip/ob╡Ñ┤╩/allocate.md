> v. 分配

**搭配**
- allocate fund/resources