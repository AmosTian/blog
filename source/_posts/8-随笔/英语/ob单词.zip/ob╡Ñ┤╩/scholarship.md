> n. 奖学金

**近义词**

- award
- prize

~ for [[outstanding]] [[academic]] / excellence performance

**相近词义**

- bonus ： n. 奖金
- commission ： n. 佣金
	高额的佣金： hefty commission

**例句**

He [[deserves]] the scholarship for outstanding academic in return for outstanding academic in return for his deligence / hard work.

[[It is no accident]] that he won the scholarship for outstanding academic in return for his deligence. 

>校领导

- 统称为：教职员工 faculty [[crew]]
- dean n. 系主任，学院院长
	head / chairman of a department
	faculty director 学术主任
- headmaster n. 校长
	president
	head
	schoolmaster
	[[principal]]
	chancellor n. 议长;(英国大学的)名誉校长;(某些美国大学的)校长

**相关搭配**

- 副手：deputy
- 代理：vice
- 学术的：academic
- 行政的：administrative


