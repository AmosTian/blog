> v. 引导

**搭配**

- lead to 导致
	- cause
	- [[trigger]]
	- [[make]] for
	- result in
	- [[bring]] about
	- [[prompt]]

**leading**

> adj. 前沿的，划界的

- cutting edge + theory / technology