> n. (团队中的)成员

**搭配**
- camera crew 摄影组成员
- flight crew 机组成员
- task crew 小组成员
- faculty crew 教职员工