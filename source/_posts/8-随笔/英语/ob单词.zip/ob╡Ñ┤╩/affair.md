> 事情


**同义词**
- [[incidence]]