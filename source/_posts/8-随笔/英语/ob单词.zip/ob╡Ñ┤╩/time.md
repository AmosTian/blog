
- in time：经过一段时间后
- on time：准时
- over time = eventually = gradually：时之已久，久而久之

时间相关搭配
- [throughout](throughout.md)
- [age](age.md)
- 直到现在： so far / up to now / up to date / until now 
- 未来：down the line = in the future
- 过去：for / over(比较长的一段时间) millions years 
- year-round 全年
- prehistoric 史前的
- Middle Ages 中世纪
- meanwhile 与此同时
- keep up to date 与时俱进
- a fraction of a second 白驹过隙
- now / currently 目前

