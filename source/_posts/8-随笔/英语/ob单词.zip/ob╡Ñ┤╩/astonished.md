> adj. 吃惊的（坏消息）

**同义词**

- [[shocked]]

**astonish**

> v. 使...十分吃惊（坏消息）

**例句**

- It astonishes me (that) he could be so thoughtless.（轻率的）

**astonishing**
> adj. 吃惊的

**同义词**

- striking
- shocking