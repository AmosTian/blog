> ... besides A.：除了A 之外还有 ... （包括A）

**例句**

- I like music besides football. 都喜欢

**同义词**

- apart from
- in addition to：
	in addition to my teaching duties

**区别**

- [[except]] 不包括后续