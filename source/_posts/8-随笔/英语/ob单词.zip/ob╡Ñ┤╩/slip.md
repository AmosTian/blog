> v. 滑，溜

**搭配**
- slip by 溜走
- slip(v.) off the tongue 顺口
- slip(n.) of the tongue / pen  口误 / 笔误
- slip my tongue 突然忘词

**slippery**
> adj. 滑的; 滑得抓不住