> adj. 近似的，大约的

>v. 近似，接近

**同义词**
- about
- some
- **roughly estimate 粗略估算**
	- approximately

**辨析**
[appropriate](appropriate.md)