> n. 生态

**ecological**
> adj. 生态的

**搭配**
- ecologically/environmentally friendly 生态 / 环境友好

**economy**
> n. 经济

- economical adj. 经济的