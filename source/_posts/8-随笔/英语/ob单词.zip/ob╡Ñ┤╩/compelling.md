> adj. 有说服力的

**搭配**
-  急迫的/严峻的问题->亟待解决的问题：compelling problem that need to be addressed
- 强有力的() 原因/证据 compelling reason/evidence 
- 推着走的/无法摆脱的：compelling need/desire/task/mission

**同义词**
- convincing adj. 有说服力的
	- strong persuasive
- He gave me a compelling reason for his late that I have to accept it.

**compel**
> v. 强迫

**同义词**
- force

**搭配** 
- be compelled to do 被迫;实逼处此
	- People will be unwilling if they are compelled to do things they don't want to do.

**相关词**
- required / compulsory  courses adj. 必修的
- selected / selective / optional courses 选修的

