> adj. 学术的

**搭配**

- [[scholarship]] for academic [[outstanding]] 学业优秀奖学金
- academic [[circle]]

