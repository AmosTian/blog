> v. 完成，实现

**同义词**

- [[accomplish]]
- complete
- [[fullfill]]
- achieve
- realise
- wort out
- carry out