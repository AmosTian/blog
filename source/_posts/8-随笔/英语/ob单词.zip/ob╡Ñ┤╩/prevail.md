> v. 充斥，完全占据

**搭配**

- prevail smell / flu / trend

**prevailing**
> adj. 普遍的


