> v. 阻止

prevent binge-eating 阻止暴饮暴食

**搭配**
- stop from doing sth
- keep sb from doing sth
- prevent sb from doing
- hinder
- hamper
- obstruct
- block
- inhibit
- interfere