> adj. 首要的，最重要的

**同义词**

- chief
	The chief pride of my job is being you commander.
	- occupation
	- business
- [major](major.md)
- [prior](prior.md) 优先的

区别：
- **重要的**
	- important
	- critical
	- crucial
	- vital
	- significant
	- noteworthy
	- play a key role in sth
	- be of great importance
	- be of utmost significance
- **必要的**
	- necessary
	- indispensable
	- inevitable
	- inexorable 不可阻挡的，不可避免的
	- [essential](essential.md) ——essential 

对...重要：
- close to your heart 
- be important you

> n. 大学校长；主角

**区别**
- [[principle]]：n. 原则(-le) 一般为名词后缀，(-pal) 一般为形容词后缀