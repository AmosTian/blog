> vt. (感情或感觉)充溢；

**搭配**

- be overwhelmed with 被充满了 
	happiness/sorrow/guilt 负罪感
	China's richest urban centres seem to be overwhelmed with traffic congestion.

**同义词**
- be occupiced by [occupy](occupy.md)
- [prevail](prevail.md)

> v. 压倒; 击败

**overwhelming**
> adj. 完全的，绝对的；压倒性的；无法抗拒的

- The evidence [against](against.md) him was overwhelming.
- The resolution was adopted by an overwhelming margin.

**搭配**
- overwhelming 压倒性的... loneliness / happiness / sadness / majority(绝大多数)  