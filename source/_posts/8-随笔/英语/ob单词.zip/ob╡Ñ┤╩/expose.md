>v. 暴露;揭露;

**搭配**
- fish exposed to water 鱼暴露于水

> n. 阐述；揭露