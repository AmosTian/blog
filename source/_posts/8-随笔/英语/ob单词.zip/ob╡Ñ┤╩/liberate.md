>  解放，摆脱约束或限制

**同义词**

- freed 解放，使自由
	- freed of pressures