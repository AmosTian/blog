> 空前的，史无前例的

The reform that is being implemented in our nation is an unprecedent, and revolutionary change.

**近义词**
- **go to extremes unheard-of elsewhere**  走向闻所未闻的极端

Unique conditions on small island allow bird populations to go to extremes unheard-of elsewhere.