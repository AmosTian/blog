> adj. 茂密的，稠密的

**搭配**
- dense hair / population
- be densely-populated 人口稠密

