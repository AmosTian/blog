> v.  比较

**搭配**

- compare A and/with/to B：将A与B对比
- A compare with/to sb/sth ：A与 sb/sth类似

**comparison**
> n. 比较

**搭配**
- in comparison 相较而言(中性)
	- by contrast
	When you look at their new system, ours seems  old-fashioned by contrast.
- in comparison to 与...相比
	In comparison to their new system, ours seems fairly outdated.
	
**comparatively**
> adv. 相对地

**相反的(对立)**
- on the contrary
- [contradict](contradict.md)