
**同义词**
- only
- merely
- just
	Food safety is no longer just a question of handling food properly in the domestic kitchen.