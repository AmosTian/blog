> adj. 先前的；有限的

**同义词**
- [[principal]]

**priority**
> n. 优先的事情

- nationwide/top priority 全国范围内的优先/最高优先级 
	- sth should remain a top priority 重中之重
- remain a priority 重中之重

He said the top priority would be to make sure they did not eat contaminated food.