> 很多

a host of social problems

**host**
- natural host 宿主

**同义词**
- varities of
- quiet of
- plenty of
- a great many
- a large number of
- a great deal of 
- a large quantity of
- a range of

**大量的**
- [abundant](abundant.md)
- masive
- plentiful
- vast
- [considerable](considerable.md)
- sizeable 可观的
- substaintial 大量的，巨额的
- countless 不计其数的
- neumerious
- immeasurable
- large-scale 大规模的（[工业](工业.md)）

**足够的**
- [adequate](adequate.md) 充足的


