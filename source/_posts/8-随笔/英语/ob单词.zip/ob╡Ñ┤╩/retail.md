> n. 零售


> v. 零售；复述，传播


> adj. 零售的，少量的

**搭配**

- retail store 零售商店

**相关词汇**

- [[wholesale]] store 批发市场