> v. 完成

**词根**
- complish v. (古)完成

**区别**
- accompany v. 陪同，陪伴
