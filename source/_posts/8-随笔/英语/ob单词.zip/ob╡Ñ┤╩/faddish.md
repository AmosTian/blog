> adj. 短暂易逝的

**同义词**
- perishable
- transient
- evanescent

**反义词** 
耐用的
- [wearing](wearing.md)
- durable
- robust
持久的
- persistent
- permanent
- sustained
- [perennial](perennial.md)
- lasting
- enduring——[endure](endure.md) v. 

**fad**
> n. (穿着、行为、言谈等方面)一时的风尚; (一时的)狂热;
