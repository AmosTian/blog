> adj. (强调+劳动，做工) 制作精美的

**搭配**
- elaborate pattern/cloth/design

> v. 详细阐述

- elaborate on sth (topic)
	- give more details on

**区别**
- illustrate v. 解释说明（带插图）