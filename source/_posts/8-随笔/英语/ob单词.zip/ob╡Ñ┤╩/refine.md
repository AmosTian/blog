>  v. 提纯;改进;更新，修正

**同义词**

- improve
- upgrade
- [progress](progress.md)
- [alter](alter.md)
- modify
- reform
- mend

**refined**
> adj. 高大上的