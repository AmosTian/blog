> ... except A：除了A以外还有...（不包括A）

**例句**

- I don't do anything except watching tv.

**同义词**
- otherthan 

**区别**
- [[besides]] 包括后续