> v. 意识到，发现

**例句**

I recognized my shortcomings when I couldn't [[finish]] the task.

> v. 识别；认可

**搭配**

- recognize people's faces and facial expressions

**同义词**

- acknowledge