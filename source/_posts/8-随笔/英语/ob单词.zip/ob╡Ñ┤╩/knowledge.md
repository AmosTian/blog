> n. 知识


> v. 知情

近义词：

- [[recognize]]
- knowing

**区别**

**adknowledge**
> v. 承认(权威、地位);