> n. 语言学


**linguist** 

> n. 语言学家


相关词
- [[anthropologist]]