> n. 人类

> adj. 人的


**humanize**
> v. 人性化，使更人道

**辨析**

- humiliate v. 羞辱，使丧失尊严
