> n. 事情，东西

**同义词**

- affiar

> v. 填满，装满

**区别**

- staff n. 全体职工
	- employee