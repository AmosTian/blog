> adj. 微小的，不明显的

**搭配**
- subtle change 

**同义词**
- faint

**反义词**
- 巨大的 [giant](giant.md)