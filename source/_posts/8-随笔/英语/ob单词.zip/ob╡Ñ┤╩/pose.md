> v. 放到面前，摆到

**搭配**
- A pose risk/challenge/threat/problem to  B
	A给B带来...
	The development of financial liberalization pose challenge to bank's ability of rish management.