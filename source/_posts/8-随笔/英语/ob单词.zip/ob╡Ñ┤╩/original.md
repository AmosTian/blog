>adj. 原始的；原创的

**originality**
> n. 独创性

**辨析**
[originate](originate.md) 起源;发源;