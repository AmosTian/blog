
**搭配**
- generation to generation 代代相传

genetically modified food 转基因食品