

**搭配**

- as long as 从句, 主句(may) ：只要 

**as if 引导虚拟语气**

1. 如果从句表示与现在事实相反，从句谓语动词用一般过去时，be动词用 were  
	- You look as if you didn’t care．
		你看上去好像并不在乎。
	
2. 从句表示与过去事实相反，谓语动词用“had＋过去分词”。  
	- He talks about Rome as if he had been there before．
		他说起罗马来好像他以前去过罗马似的。

3. 从句表示与将来事实相反，谓语动词用“would／could／might＋动词原形”
	- He opened his mouth as if he would say something．
		他张开嘴好像要说什么。 

**If 过去式,would do 主句**
- 不易实现，给建议
If I had more time after work,I'd hang out with my friends.

