> prep 自始至终，遍及

**搭配**

- throughout history ：纵观历史
- throught decades 纵观数十年

> adv. 始终