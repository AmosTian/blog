
adj. 真正的

- real：强调不违背事实
- true：客观存在的真实性
- indeed：表示加强，肯定对方的话或者加强肯定自己的语气
- actually：侧重实际，不是凭空想象或者推测的事
	- [[practical]]：实际的