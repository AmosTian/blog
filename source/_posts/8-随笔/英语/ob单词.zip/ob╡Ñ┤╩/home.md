
**搭配**

- be home to (自豪地)拥有；...之家
	- China is home to high-speed rail, with more business history than anywhere else in the world.``