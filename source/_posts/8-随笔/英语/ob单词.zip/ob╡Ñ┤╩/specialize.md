

**搭配**
- specialize in 专攻
	The professor is specialize in the field of artificial intelligence
