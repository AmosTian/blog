> v. 触发

- Skipping breakfast triggered his fainting

**近义词**
- [lead](lead.md)
- [provoke](provoke.md) 引发

> n. 触发器；诱因