> n. (暴力、疾病等坏事的)爆发，突然发生

- the outbreak of war
- An outbreak of fire or an accident is an emergency.

- erupt (物理性) 爆发 war / volcano 