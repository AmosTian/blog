> v. 唤醒(情感，记忆)
> to cause a particular memory,idea,emotion or response to occur

- evoke memory/emotion 唤醒记忆/情绪
	- The music evoked memories of her youth.

**近义词**
- recall v. 召回；唤起回忆
	- recall memory
