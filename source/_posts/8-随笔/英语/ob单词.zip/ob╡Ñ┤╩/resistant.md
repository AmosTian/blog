become resistant to drug treatment 抗药性
drug resistance