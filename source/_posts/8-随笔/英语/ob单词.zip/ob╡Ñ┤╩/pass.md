pass on 传承/传递

**passion**
> n. 激情，强烈情感

**passionate**
> adj. 热诚的；狂热的

**passive**
> adj. 消极的

pass out 晕倒