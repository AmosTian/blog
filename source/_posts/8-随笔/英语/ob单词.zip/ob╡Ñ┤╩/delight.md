> n. 高兴；令人高兴的事

**搭配**

- to the delight of：
	He has recovered, much to the delight of his friends.

> v. 使高兴; 使愉快; 使快乐;

**例句**

- This news will delight his fans all over the world.

