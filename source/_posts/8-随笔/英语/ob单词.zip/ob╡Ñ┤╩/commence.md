> v. 开始发生，着手，开始(正式)
> to begin

- The meeting is scheduled to commence at noon.