> v. 发射

> v. 启动

**搭配**

- launch a new project / campaign