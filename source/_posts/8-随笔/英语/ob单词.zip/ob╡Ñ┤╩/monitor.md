> v. 监视


> n. 显示器


- peep into 窥视

