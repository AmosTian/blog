> adj. 可行的

**feasibility**
> n. 可行性

**区别**
- flexible adj. 灵活的
	flexibility n. 灵活性；弹性