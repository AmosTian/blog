> n. 进步

**搭配**
- make progress 取得进步

**progressing**
> v. 改进

**区别**
**process**
> n. 过程 'process

> v. 处理，加工 pro'cess

- food processing and packaging 食品加工和打包
Caged/free egg 圈养蛋/散养蛋