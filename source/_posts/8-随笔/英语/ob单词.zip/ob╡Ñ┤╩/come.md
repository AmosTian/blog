
**搭配**

- come true 实现
- come from 来自
- come out 出现，出版
- come into 进入，得到
- come up 走近，上升，开始