> v. 反对

**搭配**
- object to sth 对 sth 反对
	- object sth
	- feel [[against]] sth
- objection to sth

> n. 对象；物体

**同义词**

- substance
- [[stuff]]
- body

**辨析**

- [[subject]]