> v. 使用

**搭配**

- be used doing： 被用来做某事
- used to do ： 过去常做
	- be accustomed to 习惯于
	- be always doing sth 一直做某事