> 以...的名义

- In the name of efficiency and economy, fish and chickens are raised in [giant](giant.md) factory farms.
