> v. 变得 + adj. 

**同义词**

- [[come]] into + adj.