> 总体，全面

an overview of a situation 全局观
- the big picture


