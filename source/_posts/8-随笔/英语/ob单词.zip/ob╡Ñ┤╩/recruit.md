> v. 招募

- recruit [subject](subject.md) 招募受试体(对象) / volunteers
- The professor is recruiting volunteers to complete his project.