> adj. 内在的，故有的，与生俱来的（强调继承下来的内在和固有，而且无法去除）

**例句**
- The inherent value of human life.
- Everyone has his inherent ability ,which is easily concealed by habits.

**搭配**
- A be in inherent in B：A是B中与生俱来的
	Laziness is inherent in human. 

**近义词**
- intrinsic 实在的，真正的（强调事物自身特点的起码要素和基本成分。属于物体，人性中的一部分）
	- The intrinsic value of gold.
- [genuine](genuine.md)

**inherently**
> adv. 天性地（坏）

**例句**
- They say that portraying introduced species as inherently bad is unscientific.