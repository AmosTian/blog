> adj. 相互的

**搭配**
- mutual support/understanding

**例句**
- By exchanging gifts, a person in love sometimes discovers that the love is mutual.