> adj. 沮丧的

**例句**

- They felt frustrated at the lack of progress.

**frustration**

> n. 挫败

**同义词**

- setback
- defeat
- undo
- foil