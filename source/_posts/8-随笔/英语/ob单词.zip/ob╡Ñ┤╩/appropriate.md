> adj. 适当的，恰当的

**近义词**
- proper
	- properly adjv. 合适地
- suitable

**辨析**
- [approximate](approximate.md) ：近似