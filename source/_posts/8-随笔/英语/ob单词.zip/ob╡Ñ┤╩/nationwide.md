> adj. 国家范围内的

- worldwide
- Asianwide