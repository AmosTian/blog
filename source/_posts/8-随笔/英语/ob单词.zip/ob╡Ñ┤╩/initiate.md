> n. 启动，开始

**initial**
> adj. 初始的