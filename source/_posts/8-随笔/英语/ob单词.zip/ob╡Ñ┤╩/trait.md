> n. 特点

**同义词**
- feature   
- attribute 属性      
- characteristic   
    - n. 特点
    - adj. 特有的，独特的
    - character
        - n.       
            - 性格
            - 角色
                - role         
- With further research, computers have been able to identify the physical characteristic of different creatures.