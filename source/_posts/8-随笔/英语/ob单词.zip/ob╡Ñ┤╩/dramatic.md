> adj. 戏剧性的->剧烈的

- The Wandering Earth 2 convey dramatic Chinese feelings, which melt / capture all movie goers heart.

**搭配**
- dramatic change/improve 急剧的变化
- dramatic effect 戏剧性效果

**同义词**
- unexpected
- [unprecedent](unprecedent.md)

**dramatically**
> adv. 根本上地

- change dramatically 急剧变化

**同义词**
- radically

