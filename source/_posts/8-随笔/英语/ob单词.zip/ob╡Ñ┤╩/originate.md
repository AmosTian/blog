> v. 起源;发源;

**搭配**
- originate from
- native to