> adj. 荒诞的
 
**同义词**
- ridiculous
- ludicrous
- crazy
- foolish
