odd
> adj. 奇怪的

**搭配**

- odd looking：奇怪的装束

**同义词**
- strange

> adj. 奇数的

**搭配**
- odd number 奇数

> n. odds 几率

**近义词**
- probability
- risk

**搭配**
- 比赛的胜率：the winning odds of game
- ...的可能性：Against all the odds, he made a full recovery.
- 环境： the odds against you如果环境不好

