> adj. 必不可少的，基本的

**搭配**
- essential building bloks 重要的建材

> n. 必不可少的东西；本质，要素

**essence**
> n. 本质，要素

- nature 
- intrinsic / [inherent](inherent.md) quality 

