> v. 识别;鉴定;确认

- identify the source of 溯源
- track the source of / the cause of ...的原因
- identify the importance of ... 识别...的重要性

> n. 认同;身份

- strengthen their sense of identity 认同感

**unidentified**
> adj. 未知的，身份不明的