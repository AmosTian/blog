> v. 倾向于；侧重

**搭配**

- incline to：I incline to the view that we should take no action at this stage.
- be inclined to / have an inclination to
- tend to do / have a tendenct to

**inclination**

> n. 倾向

- My natural inclination is to find a compromise.
