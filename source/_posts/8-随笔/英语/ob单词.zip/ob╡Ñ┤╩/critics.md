> n. 批判者

**反义词**
- support
- advocates
- [promise](promise.md)
- enthusiastic adj. 热情的	
	- pessimistic adj. 悲观的