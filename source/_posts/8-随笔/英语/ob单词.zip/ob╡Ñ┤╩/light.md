- light up 照亮
	lit up

**lightly**
> adv. 轻度

- lightly contaminated
- heavily infectious 重度地
- highly 高度地