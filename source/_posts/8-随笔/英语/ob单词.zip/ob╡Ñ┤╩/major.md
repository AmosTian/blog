> adj. 主要的


**同义词**

- priciple
- chief

**反义词**

- minor adj. 次要的

**搭配**

- major details / [[stuff]] 事情

> n. 专业


**majority**

> n. 大部分，多数派


**反义词**

- minority