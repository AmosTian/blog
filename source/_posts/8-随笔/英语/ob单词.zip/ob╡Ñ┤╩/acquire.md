> v. 获得

**acquisition**

> n. 获取

