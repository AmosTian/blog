> n. 利润

**搭配**
- gain / make / turn / yeild 产生 a profit 盈利