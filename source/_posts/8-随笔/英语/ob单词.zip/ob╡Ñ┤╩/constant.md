> adj. 持续不断的；恒定的

> n. 常量

**constantly**
> adv. 总是，不断地

**近义词**
- always ：be [[always]] doing sth
