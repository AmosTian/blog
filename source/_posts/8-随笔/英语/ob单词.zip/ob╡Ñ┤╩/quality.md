>n. 质

**搭配**
- be qualified as 有资格成为;够格做/当
- a necessity for sth ...的需要/必要条件

**区分**

- quantity n. 量
	- quantify v. 量化;以数量表述