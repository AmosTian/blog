> v. 操作

**manipulation**
- Stock manipulation