> v. 经历，遭受(不是好事)
> to have something necessary or unpleasant happen to you


**同义词**

- suffer
- [endure](endure.md)