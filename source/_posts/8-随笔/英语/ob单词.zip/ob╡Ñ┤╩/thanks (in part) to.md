> (部分)归功于 

Thanks in part to his help, I could finish these tough homework.