> n. 评论；引人注目


> v. 说起，谈论

**remarkable**
> adj. 非凡的；引人注目的

- He has a remarkable inner strength. 意志力

**近义词**
- eye-catching 博眼球的
	- eye-catching headline

**remarkly** 
> adv. +adj. 表示强调 adj.

remarkly = prominently(物理上)突出地 figure(人物)
[prominent](prominent.md)