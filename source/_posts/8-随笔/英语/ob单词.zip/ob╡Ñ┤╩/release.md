> v. 发行，发布

**搭配**
- release annual report
- release a new product/film 上市

>v. 减轻；解放，释放

**同义词**
- relieve 缓解 one's [pain](pain.md)/stress/burden

**搭配**
- release pressure/depression/stress/anger

**例句**
- According to medical research, doing exercise on a regular basis can release pressure.

**relief**
> n. 救济；放松

- What a relief 可轻松了