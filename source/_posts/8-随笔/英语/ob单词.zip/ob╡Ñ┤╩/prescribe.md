> vt. 开药方;

**prescription**
>n. 处方

**diagnose**
> v. 诊断

**同义词**
- dectect / dectective

**搭配**
- diagnose as/with cancer 诊断为癌症
	- cancerous tumors 癌症肿瘤

**diagnosis**
>n. 诊断书
